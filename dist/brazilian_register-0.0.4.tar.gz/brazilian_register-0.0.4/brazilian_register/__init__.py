from .cnpj.cnpj_tools import cnpj
from .cpf.cpf_tools import cpf
